// Mouse effect for TARIFFS website
document.addEventListener('DOMContentLoaded', function() {
  // Only run on desktop (screen width > 991px)
  if (window.innerWidth <= 991) {
    return;
  }

  // Create container for mouse effects
  const effectContainer = document.createElement('div');
  effectContainer.className = 'mouse-effect-container';
  effectContainer.style.position = 'fixed';
  effectContainer.style.top = '0';
  effectContainer.style.left = '0';
  effectContainer.style.width = '100%';
  effectContainer.style.height = '100%';
  effectContainer.style.pointerEvents = 'none'; // Make sure it doesn't interfere with clicks
  effectContainer.style.zIndex = '9999'; // High z-index to be on top
  effectContainer.style.overflow = 'hidden';
  document.body.appendChild(effectContainer);

  // Mouse position
  let mouseX = 0;
  let mouseY = 0;

  // Track mouse position
  document.addEventListener('mousemove', function(e) {
    mouseX = e.clientX;
    mouseY = e.clientY;

    // Create dollar sign or tariff symbol on mouse move (throttled)
    if (Math.random() > 0.8) { // Increased frequency (was 0.85)
      createSymbol(mouseX, mouseY);
    }
  });

  // Create a symbol that follows the mouse
  const follower = document.createElement('div');
  follower.className = 'mouse-follower';
  follower.style.position = 'absolute';
  follower.style.width = '60px'; // Increased size (was 40px)
  follower.style.height = '60px'; // Increased size (was 40px)
  follower.style.borderRadius = '50%';
  follower.style.background = 'radial-gradient(circle, rgba(38, 90, 190, 0.2) 0%, rgba(38, 90, 190, 0) 70%)'; // Increased opacity (was 0.1)
  follower.style.boxShadow = '0 0 15px rgba(38, 90, 190, 0.5)'; // Increased glow (was 10px, 0.3)
  follower.style.transform = 'translate(-50%, -50%)';
  follower.style.pointerEvents = 'none';
  follower.style.zIndex = '10000';
  effectContainer.appendChild(follower);

  // Follower position with smooth animation
  let followerX = 0;
  let followerY = 0;

  // Animation loop for smooth follower movement
  function animateFollower() {
    // Smooth follow with easing
    followerX += (mouseX - followerX) * 0.1;
    followerY += (mouseY - followerY) * 0.1;

    follower.style.left = followerX + 'px';
    follower.style.top = followerY + 'px';

    requestAnimationFrame(animateFollower);
  }

  animateFollower();

  // Create floating symbols
  function createSymbol(x, y) {
    const symbols = ['$', '¥', '€', '£', '₿', 'TARIFFS'];
    const symbol = document.createElement('div');
    symbol.className = 'floating-symbol';
    symbol.textContent = symbols[Math.floor(Math.random() * symbols.length)];
    symbol.style.position = 'absolute';
    symbol.style.left = x + 'px';
    symbol.style.top = y + 'px';
    symbol.style.color = 'rgba(38, 90, 190, ' + (Math.random() * 0.5 + 0.5) + ')'; // Increased opacity (was 0.2)
    symbol.style.fontSize = (Math.random() * 16 + 14) + 'px'; // Increased size (was 10-24px)
    symbol.style.fontWeight = 'bold';
    symbol.style.fontFamily = 'Arial, sans-serif';
    symbol.style.transform = 'translate(-50%, -50%)';
    symbol.style.pointerEvents = 'none';
    symbol.style.zIndex = '10000';
    symbol.style.textShadow = '0 0 8px rgba(38, 90, 190, 0.8)'; // Increased glow (was 5px, 0.5)
    effectContainer.appendChild(symbol);

    // Animate the symbol
    let opacity = 1;
    let posY = y;
    let posX = x + (Math.random() * 40 - 20); // Random horizontal drift

    const animate = setInterval(() => {
      opacity -= 0.015; // Slower fade (was 0.02)
      posY -= 1.5; // Faster upward movement (was 1)

      symbol.style.opacity = opacity;
      symbol.style.top = posY + 'px';
      symbol.style.left = posX + 'px';

      if (opacity <= 0) {
        clearInterval(animate);
        symbol.remove();
      }
    }, 30);

    // Remove after animation completes (backup)
    setTimeout(() => {
      if (symbol.parentNode) {
        symbol.remove();
      }
    }, 4000); // Longer duration (was 3000)
  }

  // Create a ripple effect on click
  document.addEventListener('click', function(e) {
    createRipple(e.clientX, e.clientY);
  });

  // Create ripple effect
  function createRipple(x, y) {
    const ripple = document.createElement('div');
    ripple.className = 'mouse-ripple';
    ripple.style.position = 'absolute';
    ripple.style.left = x + 'px';
    ripple.style.top = y + 'px';
    ripple.style.width = '15px'; // Increased size (was 10px)
    ripple.style.height = '15px'; // Increased size (was 10px)
    ripple.style.borderRadius = '50%';
    ripple.style.border = '3px solid rgba(38, 90, 190, 0.9)'; // Thicker border, more opacity (was 2px, 0.8)
    ripple.style.transform = 'translate(-50%, -50%)';
    ripple.style.pointerEvents = 'none';
    ripple.style.zIndex = '10000';
    effectContainer.appendChild(ripple);

    // Animate the ripple
    let size = 15; // Increased starting size (was 10)
    let opacity = 1;

    const animate = setInterval(() => {
      size += 6; // Faster expansion (was 5)
      opacity -= 0.025; // Slower fade (was 0.03)

      ripple.style.width = size + 'px';
      ripple.style.height = size + 'px';
      ripple.style.opacity = opacity;

      if (opacity <= 0) {
        clearInterval(animate);
        ripple.remove();
      }
    }, 20);
  }

  // Handle window resize - disable effect if window becomes too small
  window.addEventListener('resize', function() {
    if (window.innerWidth <= 991) {
      // Remove the effect container if screen becomes too small
      if (effectContainer && effectContainer.parentNode) {
        effectContainer.parentNode.removeChild(effectContainer);
      }
    }
  });
});
